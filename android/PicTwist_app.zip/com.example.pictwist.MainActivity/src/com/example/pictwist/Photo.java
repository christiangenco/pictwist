package com.example.pictwist;


import java.util.ArrayList;

import com.koushikdutta.urlimageviewhelper.UrlImageViewHelper;

import android.util.Log;
import android.widget.ImageView;

public class Photo {

	public class Comment {

		public String text;
		public String username;
		public String date;	

		public Comment(String text, String username, String date) {
			this.text = text;
			this.username = username;
			this.date = date;
		}
	}

	public String name;
	public String src;
	public String thumb;
	public ArrayList<Comment> comments = new ArrayList<Comment>();
	

	public Photo(String name, String src, String thumb_url) {
		this.name = name;
		this.src = src;
		this.thumb = thumb_url;
	}
	
	

	public void addComment(String text, String username, String date) {
		comments.add(new Comment(text, username, date));
	}

	// simple log function
		public void l(String m) {
			Log.i("PT_XML", m);
		}
	
	/*
	 * UrlImageViewHelper will asynchronously load the image if it is not already loaded/cached and then place it in the ImageView
	 */
	
	public void loadThumb(ImageView v) {
		UrlImageViewHelper.setUrlDrawable(v, thumb);
	}

	public void loadPic(ImageView v) {
		UrlImageViewHelper.setUrlDrawable(v, src);
	}
	
	
	public String toString() {
		return name + " (" + src + ", " + thumb + ")  Comments: " + comments.size();
	}
	
}
