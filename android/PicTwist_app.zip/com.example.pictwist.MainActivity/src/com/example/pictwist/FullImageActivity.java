package com.example.pictwist;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import com.koushikdutta.urlimageviewhelper.UrlImageViewHelper;
 
public class FullImageActivity extends Activity {
 
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.full_image);
 
        Intent i = getIntent();

        String url = i.getExtras().getString("URL");
 
        ImageView imageView = (ImageView) findViewById(R.id.full_image_view);
        //imageView.setImageResource(imageAdapter.mThumbIds[position]);
        //imageAdapter.photos.get(position).loadPic(imageView);
        
        // asynchronously load the image if it is not already cached and put it in the ImageView
        UrlImageViewHelper.setUrlDrawable(imageView, url);
    }
 
}
