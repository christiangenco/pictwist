package com.example.pictwist;

import java.io.IOException;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

import android.content.Context;
import android.content.Intent;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

public class MainActivity extends Activity {	
	
	public ArrayList<Photo> photos = new ArrayList<Photo>();
	
	// simple log function
	public void l(String m) {
		Log.i("PT_XML", m);
	}
	
	public GridView gridview;	
	private static String PHOTOS_URL = "http://ec2-54-242-42-104.compute-1.amazonaws.com/pictwist/photos.xml.php"; // I put this here instead of in res because xml files don't like hyphens
	public Context mContext;
			
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pic_twist);
    	
	    gridview = (GridView) findViewById(R.id.gridview);
	    mContext = this;
	    
       // PHOTOS_URL = getResources().getString(R.string.photos_url);        
        new PhotosParserTask().execute(PHOTOS_URL); 	
	   
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
    

    
public class PhotosParserTask extends AsyncTask<String, Integer, ArrayList<Photo>> {
    	
    	// TODO Loading bar?
    	
		@Override
		protected ArrayList<Photo> doInBackground(String... params) {
			ArrayList<Photo> photos = null;
			HttpClient client = new DefaultHttpClient();
			HttpGet get = new HttpGet(params[0]);
			try {
				HttpResponse response = client.execute(get);
				HttpEntity entity = response.getEntity();
				if (null != entity) {
					photos = parseXML(EntityUtils.toString(entity));
				}
			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return photos;
		}
		
		public ArrayList<Photo> parseXML(String xml) {
			ArrayList<Photo> photos = new ArrayList<Photo>();
			
			try {

				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder = factory.newDocumentBuilder();
				InputSource is = new InputSource(new StringReader(xml));
				Document doc = builder.parse(is);
				doc.getDocumentElement().normalize();

				NodeList photoNodes = doc.getElementsByTagName("photo");

				for (int i = 0; i < photoNodes.getLength(); i++) {

					Element photoElement = (Element) photoNodes.item(i);

					String name = photoElement.getAttribute("name");
					String src = photoElement.getAttribute("src");
					String thumb = photoElement.getAttribute("thumb");

					Photo photo = new Photo(name, src, thumb);
					
					NodeList commentNodes = photoElement.getElementsByTagName("comment");
					
					for (int j = 0; j < commentNodes.getLength(); j++) {
						
						Element commentElement = (Element) commentNodes.item(j);
						
						String text = commentElement.getAttribute("text");						
						String username = commentElement.getAttribute("username");
						String date = commentElement.getAttribute("date");
						
						photo.addComment(text, username, date);
					}					
					
					photos.add(photo);
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return photos;
		}		 
		
		@Override
		public void onPostExecute(ArrayList<Photo> p) {
			photos = p;
			
		    gridview.setAdapter(new ImageAdapter(mContext, photos));
		    
		    gridview.setOnItemClickListener(new OnItemClickListener() {
		        public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
		            
		        	// Sending image url to FullScreenActivity
	                Intent i = new Intent(getApplicationContext(), FullImageActivity.class);
	                i.putExtra("URL", photos.get(position).src);
	                startActivity(i);

		        }
		    });
		}
	}

}
